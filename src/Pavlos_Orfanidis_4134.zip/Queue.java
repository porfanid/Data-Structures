/**
 *Pavlos Orfanidis 4134
 *Pantelis Rempakos 4279
 *Giorgos Kamaridis 4264
 */
class Queue<Item> {
    
    Stack<Item> stack;

    Queue() {
        stack=new Stack<Item>();
    }
    
    boolean isEmpty() {
        return stack.isEmpty();
    }

    // insert new item in the queue
    void put(Item item) {
        stack.push(item);
    }

    // extract least recent item from the queue
    Item get() {
        return stack.pop();
    }

    public String toString(){
        String result="";

        Item[] list=stack.get();
        for(int i=0;i<list.length;i+=2)
        {
            result += (list[i])+" - "+(list[i+1]) +", ";
        }
        
        int lastCommaPosition=result.length();
        
        if(lastCommaPosition-2>0)
        {
            lastCommaPosition-=2;
        }
        
        return result.substring(0,lastCommaPosition);
    }
}
