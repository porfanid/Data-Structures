/**
 *Pavlos Orfanidis 4134
 *Pantelis Rempakos 4279
 *Giorgos Kamaridis 4264
 */
import java.util.Arrays;

public class Stack<Item>{
	
    private static final int DEFAULT_CAPACITY = 10;

    
    private static final Object[] EMPTY_ELEMENTDATA = {};
    
    private Object[] elementData; // non-private to simplify nested class access
    
    
    private int size;
    
    
    
    private static final int MAX_ARRAY_SIZE = Integer.MAX_VALUE - 8;
    
    /**
     * Constructs an empty list with the specified initial capacity.
     *
     * @param  initialCapacity  the initial capacity of the list
     * @throws IllegalArgumentException if the specified initial capacity
     *         is negative
     */
    public Stack(int initialCapacity) {
        if (initialCapacity < 0)
            throw new IllegalArgumentException("Illegal Capacity: "+
                                               initialCapacity);
        this.elementData = new Object[initialCapacity];
    }
    
    public Stack() {
		this.elementData = EMPTY_ELEMENTDATA;
    }
    
    /**
     * Trims the capacity of this <tt>ArrayList</tt> instance to be the
     * list's current size.  An application can use this operation to minimize
     * the storage of an <tt>ArrayList</tt> instance.
     */
    public void trimToSize() {
        
        if (size < elementData.length) {
            elementData = Arrays.copyOf(elementData, size);
        }
    }
    
    public void ensureCapacity(int minCapacity) {
        int minExpand;
        
        if(elementData != EMPTY_ELEMENTDATA)
        {
        	minExpand=0;
        }
        else
        {
        	minExpand=DEFAULT_CAPACITY;
        }
            

        if (minCapacity > minExpand) {
            ensureExplicitCapacity(minCapacity);
        }
    }
    
    
    private void ensureCapacityInternal(int minCapacity) {
        if (elementData == EMPTY_ELEMENTDATA) {
            minCapacity = Math.max(DEFAULT_CAPACITY, minCapacity);
        }

        ensureExplicitCapacity(minCapacity);
    }

    private void ensureExplicitCapacity(int minCapacity) {
        

        // overflow-conscious code
        if (minCapacity - elementData.length > 0)
        {
            grow(minCapacity);
        }
    }
    
    

    
    private void grow(int minCapacity) {
        // overflow-conscious code
        int oldCapacity = elementData.length;
        
        int newCapacity = oldCapacity + (oldCapacity >> 1);
        
        if (newCapacity - minCapacity < 0)
        {
            newCapacity = minCapacity;
        }
        if (newCapacity - MAX_ARRAY_SIZE > 0)
        {
            newCapacity = hugeCapacity(minCapacity);
        }
        // minCapacity is usually close to size, so this is a win:
        elementData = Arrays.copyOf(elementData, newCapacity);
    }

    private static int hugeCapacity(int minCapacity) {
        if (minCapacity < 0) // overflow
        {
            throw new OutOfMemoryError();
        }
        
        int returnValue;
        
        if(minCapacity > MAX_ARRAY_SIZE)
        {
        	returnValue=Integer.MAX_VALUE;
        }else
        {
        	returnValue=MAX_ARRAY_SIZE;
        }
        return returnValue;
    }
    
    
    
    private void rangeCheck(int index)throws IndexOutOfBoundsException {
        try {
        	Object temp=elementData[index];
        }catch(IndexOutOfBoundsException e)
        {
        	throw new IndexOutOfBoundsException("The element in the "+Parentheses.numberToOrder(index)+" position does not exist.");
        }
    }
    
    @SuppressWarnings("unchecked")
    Item elementData(int index) {
        try {
    	return (Item) elementData[index];
        }catch(IndexOutOfBoundsException e)
        {
        	System.err.println("The number of right parentheses is greater than the one of the left parentheses");
        	System.exit(0);
        	return null;
        } 
    }
    
    
    public Item remove(int index) {
        try {
        	rangeCheck(index);
        }catch(Exception e)
        {
        	System.err.println(e.getMessage());
        }
        
        Item oldValue = elementData(index);
        
        int numMoved = size - index - 1;
        if (numMoved > 0)
        {
            System.arraycopy(elementData, index+1, elementData, index, numMoved);
        }
        elementData[--size] = null; // clear to let Garbage Collector do its work

        return oldValue;
    }
    
	
//stack.isEmpty()
    boolean isEmpty() {
    	return size == 0;
    }
    
    // insert new item on top of the stack
    void push(Item item) {
    	ensureCapacityInternal(size + 1);  // Increments modCount!!
        elementData[size++] = item; 
    }

    // extract most recent item from the top of the stack
    Item pop(){
    	Item last=remove(size-1);
    	trimToSize();
    	return last;
    }

    @SuppressWarnings("unchecked")
	Item[] get(){
    	return (Item[]) elementData;
    }
}
