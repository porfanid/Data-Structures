/**
 *Pavlos Orfanidis 4134
 *Pantelis Rempakos 4279
 *Giorgos Kamaridis 4264
 */

public class Parentheses {

    private static void PrintOutput(Queue<Integer> Q) {
        System.out.println(Q);
    }

    
    public static String numberToOrder(int number)
    {
    	if(number==1)
    	{
    		return number+"st";
    	}
    	if(number==2)
		{
			return number+"nd";
		}
    	if(number==3)
    	{
			return number+"rd";
		}
    	return number+"th";
    }
    
    private static void ParseInput(String str){
    	
    	// a variable to check whether the programm has been run without errors
    	boolean isCorrect=true;
        
    	
    	Stack<Pair> S = new Stack<Pair>();
        Queue<Integer> Q = new Queue<Integer>();
        int N = str.length(); // number of characters in str
        
        // creating a string with the left brackets
        String importantLeft="({[";
        // creating a string with the right brackets
        String importantRight=")}]";
        // creating a string with all the brackets
        String important=importantLeft+importantRight;
        // to check whether a character is a bracket and
        //if the bracket that is supposed to close the first one is of the same kind
        //or not.
        
        
        for (int i = 0; i < N; i++) {
        	
            char c = str.charAt(i); // character at position i of str
            
            
            // method indexOf takes a character as an argument and returns:
            //i) the index of the character if it is part of the string
            //ii) -1 if the character does not exist in the string.
            if(important.indexOf(c)==-1)
            {
                continue;
            }
            
            if(importantLeft.indexOf(c)>=0)
            {
                S.push(new Pair(c,i));
                continue;
            }

            if(importantRight.indexOf(c)>=0)
            {
                Pair temp;
				
					temp = S.pop();
				
					isCorrect=false;
					//e.printStackTrace();
					//System.err.println(e.getMessage());
					//break;
				
				
                char d=temp.getC();
                int j=temp.getP();
                //getting the position of each bracket in the String I have made.
                //if it is in the same position, then it is of the same kind.
                int indexRight=importantRight.indexOf(c);
                int indexLeft=importantLeft.indexOf(d);
                
                if(indexRight==indexLeft)
                {
                    Q.put(j);
                    Q.put(i);
                }else{
                	isCorrect=false;
                    System.err.println("Syntax Error: The bracket in the "+numberToOrder(j+1)+" position does not match the bracket in the "+numberToOrder(i+1)+" position");
                    //return;
                }
            }
        }
        
        if(isCorrect)
        {
        	PrintOutput(Q);
        }
    }

    public static void main(String[] args) {
        System.out.print("Enter input string > ");
        In.init();
        String str = In.getString();   // read next character
        System.out.println("Input string = " + str + " , length = " + str.length());
        ParseInput(str);
        
    }
}
